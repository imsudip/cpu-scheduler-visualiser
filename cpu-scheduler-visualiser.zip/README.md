<h2> CPU Scheduling Algorithm</h2>
This is a CPU scheduling algorithms visualizer which gives the comparison between various scheduling algorithms.<br><br>
Total 9 scheduling algorithms have been implemented.<br><br>
Included a new scheduling algorithm, which is a mixture of round robin scheduling algorithm and prioirity scheduling algorithm.<br><br>
